// Quick capture. Readover is read-first, so this stays small: a title and a body.
import * as store from '../store.js';
import { canWrite, displayName, writeNote } from '../library.js';
import { openSheet, toast, el, closeTop } from './overlay.js';

const slug = (s) =>
  s
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[\\/:*?"<>|#^[\]]+/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'Untitled';

export function initCompose(app) {
  const sheet = document.getElementById('compose-sheet');
  const form = document.getElementById('compose-form');

  form.onsubmit = async (e) => {
    e.preventDefault();
    const f = form.elements;
    const src = store.getSource(f.source.value);
    const title = f.title.value.trim();
    const folder = f.folder.value.trim().replace(/^\/|\/$/g, '');
    const path = `${folder ? `${folder}/` : ''}${slug(title)}.md`;
    const text = `# ${title}\n\n${f.body.value.trim()}\n`;
    const btn = form.querySelector('[type=submit]');
    btn.disabled = true;
    try {
      const existing = await store.items.get(store.keyOf(src.id, path));
      if (existing && !confirm(`"${path}" already exists. Replace it?`)) return;
      const item = await writeNote(src, path, text, { message: `Readover: add ${path}` });
      localStorage.removeItem('readover.draft');
      form.reset();
      closeTop();
      toast(`Saved to ${displayName(src)}`);
      app.showFirst(item);
    } catch (err) {
      toast(err.message);
    } finally {
      btn.disabled = false;
    }
  };

  // Keep an unsent draft per device.
  form.addEventListener('input', () => {
    try {
      localStorage.setItem('readover.draft', JSON.stringify({ title: form.elements.title.value, body: form.elements.body.value }));
    } catch {}
  });

  return {
    async open() {
      const writable = store.getSources().filter(canWrite);
      if (!writable.length) {
        toast('To write notes, add a GitHub token in Settings or open a folder on this device.');
        return;
      }
      const prefs = store.getPrefs();
      const sel = form.elements.source;
      sel.replaceChildren(...writable.map((s) => el('option', { value: s.id }, displayName(s))));
      if (writable.some((s) => s.id === prefs.scope)) sel.value = prefs.scope;
      if (prefs.folder) form.elements.folder.value = prefs.folder;
      const folders = new Set((await store.items.all()).filter((i) => i.sourceId === sel.value && i.folder).map((i) => i.folder));
      document.getElementById('compose-folders').replaceChildren(...[...folders].sort().map((f) => el('option', { value: f })));
      try {
        const draft = JSON.parse(localStorage.getItem('readover.draft') || 'null');
        if (draft) {
          form.elements.title.value = draft.title || '';
          form.elements.body.value = draft.body || '';
        }
      } catch {}
      const done = openSheet(sheet);
      form.elements.title.focus();
      await done;
    },
  };
}
