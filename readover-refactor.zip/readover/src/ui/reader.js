// Full-screen note reader with in-place editing (commits to GitHub or writes to the folder).
import { readText, writeNote, canWrite } from '../library.js';
import { parseNote } from '../markdown.js';
import { getSource } from '../store.js';
import { pushOverlay, el, icon, toast } from './overlay.js';
import { resolveImages } from './card.js';

/**
 * @param item  feed item
 * @param opts  { starred, onStar(bool) → Promise<bool>, highlight?, onSaved(item, text) }
 */
export async function openNote(item, opts = {}) {
  const src = getSource(item.sourceId);
  let text = await readText(item);
  let note = parseNote(text, item.path);
  let starred = Boolean(opts.starred);

  const star = el('button', { class: 'icon-btn star-btn', 'aria-pressed': String(starred), title: 'Favourite' }, icon('star'));
  const editBtn = canWrite(src) ? el('button', { class: 'btn' }, 'Edit') : null;
  const back = el('button', { class: 'icon-btn', 'aria-label': 'Back' }, icon('back'));
  const status = el('span', { class: 'status' });
  const bar = el('div', { class: 'reader-bar' }, back, el('span', { class: 'title' }, note.title), status, star, editBtn);
  const scroll = el('div', { class: 'reader-scroll', tabindex: '-1' });
  const root = el('div', { class: 'reader', role: 'dialog', 'aria-modal': 'true', 'aria-label': note.title }, bar, scroll);

  const githubUrl =
    src?.type === 'github'
      ? `https://github.com/${src.owner}/${src.repo}/blob/${encodeURIComponent(src.branch || 'main')}/${item.path
          .split('/')
          .map(encodeURIComponent)
          .join('/')}`
      : null;

  const renderArticle = () => {
    const prose = el('div', { class: 'prose' });
    prose.innerHTML = note.html;
    resolveImages(prose, item);
    const crumbs = item.folder ? item.folder.split('/') : [];
    const article = el(
      'article',
      { class: 'reader-article' },
      el('div', { class: 'card-where' }, el('span', {}, ...[src?.name || '', ...crumbs].map((c) => el('span', { class: 'crumb' }, c)))),
      el('h1', { class: 'card-title' }, note.title),
      prose,
      el(
        'p',
        { class: 'reader-foot' },
        item.path,
        githubUrl ? ' — ' : '',
        githubUrl ? el('a', { href: githubUrl, target: '_blank', rel: 'noopener' }, 'View on GitHub') : ''
      )
    );
    scroll.replaceChildren(article);
    return prose;
  };

  const prose = renderArticle();
  document.body.append(root);
  scroll.focus();

  if (opts.highlight) {
    const needle = opts.highlight.text.replace(/[*_`=>\[\]]/g, '').replace(/\s+/g, ' ').trim().slice(0, 50);
    const target = [...prose.querySelectorAll('blockquote, mark, li, p')].find((n) =>
      n.textContent.replace(/\s+/g, ' ').includes(needle)
    );
    if (target) {
      target.scrollIntoView({ block: 'center' });
      target.classList.add('flash');
    }
  }

  let editing = false;
  let textarea = null;
  const close = pushOverlay(() => root.remove());
  back.onclick = () => {
    if (editing && textarea.value !== text && !confirm('Discard your changes?')) return;
    close();
  };

  star.onclick = async () => {
    starred = !starred;
    star.setAttribute('aria-pressed', String(starred));
    await opts.onStar?.(starred);
  };

  if (editBtn) {
    editBtn.onclick = async () => {
      if (!editing) {
        editing = true;
        textarea = el('textarea', { spellcheck: 'true', 'aria-label': 'Note source' });
        textarea.value = text;
        scroll.replaceChildren(el('div', { class: 'editor' }, textarea));
        editBtn.textContent = 'Save';
        editBtn.classList.add('btn-primary');
        textarea.focus();
        return;
      }
      if (textarea.value === text) {
        editing = false;
        editBtn.textContent = 'Edit';
        editBtn.classList.remove('btn-primary');
        renderArticle();
        return;
      }
      editBtn.disabled = true;
      status.textContent = src.type === 'github' ? 'Committing…' : 'Saving…';
      try {
        const updated = await writeNote(src, item.path, textarea.value);
        Object.assign(item, updated);
        text = textarea.value;
        note = parseNote(text, item.path);
        editing = false;
        editBtn.textContent = 'Edit';
        editBtn.classList.remove('btn-primary');
        renderArticle();
        status.textContent = '';
        toast('Saved');
        opts.onSaved?.(item, text);
      } catch (err) {
        status.textContent = '';
        toast(err.message);
      } finally {
        editBtn.disabled = false;
      }
    };
  }
}
