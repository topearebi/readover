// Settings sheet: libraries, token, appearance, storage.
import * as store from '../store.js';
import { displayName } from '../library.js';
import * as github from '../sources/github.js';
import * as local from '../sources/local.js';
import { openSheet, el, toast } from './overlay.js';

const $ = (id) => document.getElementById(id);

export function lastSyncText(id) {
  const t = Number(localStorage.getItem(`readover.lastSync.${id}`));
  if (!t) return 'Not synced yet';
  const mins = Math.round((Date.now() - t) / 60000);
  if (mins < 1) return 'Synced just now';
  if (mins < 60) return `Synced ${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 48) return `Synced ${hrs} h ago`;
  return `Synced ${Math.round(hrs / 24)} days ago`;
}

/** @param app { syncSource(src), addFolder(), reimport(src), sourcesChanged(), applyTheme() } */
export function initSettings(app) {
  const sheet = $('settings-sheet');
  const form = $('repo-form');
  const tokenInput = $('token-input');

  async function renderSources() {
    const list = $('source-list');
    const sources = store.getSources();
    const counts = new Map();
    for (const it of await store.items.all()) counts.set(it.sourceId, (counts.get(it.sourceId) || 0) + 1);

    if (!sources.length) {
      list.replaceChildren(el('p', { class: 'empty-sources' }, 'Nothing connected yet. Add a GitHub repo of notes, or open a folder on this device.'));
      return;
    }
    const rows = await Promise.all(
      sources.map(async (src) => {
        const n = counts.get(src.id) || 0;
        const bits = [];
        if (src.type === 'github') {
          bits.push(`${src.owner}/${src.repo}${src.root ? `/${src.root}` : ''} on ${src.branch || 'main'}`);
        } else {
          bits.push(src.mode === 'handle' ? 'Folder on this device' : 'Imported copy of a folder');
        }
        bits.push(`${n} ${n === 1 ? 'item' : 'items'}`);
        bits.push(lastSyncText(src.id));
        const detail = el('div', { class: 'source-detail' }, bits.join(', '));
        if (src.type === 'github' && !github.canWrite(src)) {
          detail.append(el('br'), 'Read only: favourites stay on this device until you add a token.');
        }
        if (src.type === 'local' && src.mode === 'handle') {
          const perm = await local.permissionState(src).catch(() => 'missing');
          if (perm !== 'granted') detail.append(el('br'), el('span', { class: 'warn' }, 'Needs your permission to read again.'));
        }
        const actions = el('div', { class: 'source-actions' });
        const add = (label, fn, cls) => {
          const b = el('button', { class: cls }, label);
          b.onclick = fn;
          actions.append(b);
        };
        if (src.type === 'local' && src.mode === 'import') add('Re-import', () => app.reimport(src));
        else add('Sync', () => app.syncSource(src, { userGesture: true }).then(renderSources));
        if (src.type === 'github') add('Edit', () => showForm(src));
        add('Remove', async () => {
          if (!confirm(`Remove "${displayName(src)}" from Readover? Your files are not touched; favourites synced to the repo are kept there.`)) return;
          await store.removeSource(src.id);
          app.sourcesChanged();
          renderSources();
        }, 'remove');
        return el('div', { class: 'source' }, el('div', { class: 'source-name' }, displayName(src)), detail, actions);
      })
    );
    list.replaceChildren(...rows);
  }

  function showForm(src = null) {
    form.hidden = false;
    form.reset();
    $('repo-form-title').textContent = src ? `Edit ${displayName(src)}` : 'Add a GitHub repo';
    form.elements.id.value = src?.id || '';
    if (src) {
      form.elements.repo.value = `${src.owner}/${src.repo}`;
      form.elements.branch.value = src.branch || '';
      form.elements.root.value = src.root || '';
      form.elements.ignore.value = src.ignore || '';
      form.elements.name.value = src.name || '';
      form.elements.token.value = src.token || '';
    }
    form.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    form.elements.repo.focus();
  }

  form.querySelector('[data-cancel]').onclick = () => (form.hidden = true);
  form.onsubmit = async (e) => {
    e.preventDefault();
    const f = form.elements;
    const parsed = github.parseRepoInput(f.repo.value);
    if (!parsed) {
      toast('Enter the repo as owner/repo, or paste its GitHub link.');
      return;
    }
    const submit = form.querySelector('[type=submit]');
    submit.disabled = true;
    const existing = f.id.value ? store.getSource(f.id.value) : null;
    const src = {
      ...(existing || {}),
      id: existing?.id || store.newId('gh'),
      type: 'github',
      owner: parsed.owner,
      repo: parsed.repo,
      branch: f.branch.value.trim() || parsed.branch,
      root: (f.root.value.trim() || parsed.root).replace(/^\/|\/$/g, ''),
      ignore: f.ignore.value.trim(),
      token: f.token.value.trim(),
      name: f.name.value.trim(),
    };
    try {
      if (!src.branch) src.branch = (await github.repoInfo(src)).defaultBranch;
      if (!src.name) src.name = src.root ? `${src.repo}/${src.root.split('/').pop()}` : src.repo;
      store.saveSource(src);
      form.hidden = true;
      app.sourcesChanged();
      await app.syncSource(src, { userGesture: true });
      renderSources();
    } catch (err) {
      toast(err.message);
    } finally {
      submit.disabled = false;
    }
  };

  $('add-repo-btn').onclick = () => showForm();
  $('add-folder-btn').onclick = () => app.addFolder().then(renderSources);
  $('folder-input').onchange = (e) => app.importFiles(e.target.files).then(renderSources);

  tokenInput.onchange = () => {
    store.setToken(tokenInput.value);
    toast(tokenInput.value.trim() ? 'Token saved on this device' : 'Token removed');
    renderSources();
  };

  $('theme-select').onchange = (e) => {
    store.setPrefs({ theme: e.target.value });
    app.applyTheme();
  };
  $('mix-select').onchange = (e) => store.setPrefs({ highlightMix: Number(e.target.value) });

  $('clear-books-btn').onclick = async () => {
    const githubIds = new Set(store.getSources().filter((s) => s.type === 'github').map((s) => s.id));
    const all = await store.blobs.all();
    await store.blobs.bulkDelete(all.filter((b) => githubIds.has(b.sourceId)).map((b) => b.key));
    toast('Downloaded books removed. They download again when opened.');
    showStorage();
  };
  $('reset-seen-btn').onclick = async () => {
    if (!confirm('Forget which items you have seen? Favourites and hidden items are kept.')) return;
    const rows = await store.state.all();
    await store.state.bulkPut(rows.map((r) => ({ ...r, lastSeen: 0, seen: 0 })));
    toast('Reading history cleared');
  };

  async function showStorage() {
    const info = $('storage-info');
    if (!navigator.storage?.estimate) {
      info.textContent = 'Storage details are not available in this browser.';
      return;
    }
    const { usage = 0, quota = 0 } = await navigator.storage.estimate();
    const persisted = (await navigator.storage.persisted?.()) || false;
    const mb = (b) => (b / 1048576 < 1024 ? `${(b / 1048576).toFixed(1)} MB` : `${(b / 1073741824).toFixed(1)} GB`);
    info.textContent = `Using ${mb(usage)} of ${mb(quota)} available. ${
      persisted ? 'The browser will keep this data.' : 'The browser may clear this data if space runs low.'
    }`;
  }

  return {
    async open() {
      const prefs = store.getPrefs();
      tokenInput.value = store.getToken();
      $('theme-select').value = prefs.theme;
      $('mix-select').value = String(prefs.highlightMix >= 0.7 ? 0.8 : prefs.highlightMix > 0 ? 0.5 : 0);
      form.hidden = true;
      renderSources();
      showStorage();
      const done = openSheet(sheet);
      if (!store.getSources().length) showForm();
      await done;
    },
    refresh: renderSources,
  };
}
